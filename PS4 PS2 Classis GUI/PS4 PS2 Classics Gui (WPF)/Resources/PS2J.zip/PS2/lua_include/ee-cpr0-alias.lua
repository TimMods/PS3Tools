cpr = {}

cpr.index		= 0
cpr.random		= 1
cpr.entrylo0	= 2
cpr.entrylo1	= 3
cpr.context		= 4
cpr.pagemask	= 5
cpr.wired		= 6
cpr.badvaddr	= 8
cpr.count		= 9
cpr.entryhi		= 10
cpr.compare		= 11
cpr.status		= 12
cpr.cause		= 13
cpr.epc			= 14
cpr.prid		= 15
cpr.config		= 16
cpr.badpaddr	= 23
cpr.hwbk		= 24
cpr.pccr		= 25
cpr.taglo		= 28
cpr.taghi		= 29
cpr.errorepc	= 30

return cpr